-- full_adder.vhd
-- 02138 Digital Electronics 1, Lab 2, Section 2.1
-- Counts the number of 1's among the inputs a, b, c.
-- Result as a 2-bit binary number: t (MSB) and s (LSB).

library ieee;
use ieee.std_logic_1164.all;

entity full_adder is
  port ( a, b, c : in  std_logic;
         s, t    : out std_logic );
end full_adder;

architecture behavior of full_adder is
begin
  s <= a xor b xor c;                          -- sum bit
  t <= (a and b) or (a and c) or (b and c);    -- carry bit (majority)
end behavior;
