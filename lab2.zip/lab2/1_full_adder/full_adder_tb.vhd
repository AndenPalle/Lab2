-- full_adder_tb.vhd
-- Testbench for full_adder: runs through all 8 input combinations
-- and checks that t&s equals the number of 1's on a, b, c.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity full_adder_tb is
end full_adder_tb;

architecture test of full_adder_tb is
  signal a_in, b_in, c_in : std_logic;
  signal s_out, t_out     : std_logic;
begin

  dut: entity work.full_adder
    port map ( a => a_in, b => b_in, c => c_in,
               s => s_out, t => t_out );

  stimulus: process
    variable abc      : unsigned(2 downto 0);
    variable expected : unsigned(1 downto 0);
  begin
    for i in 0 to 7 loop
      abc  := to_unsigned(i, 3);
      a_in <= abc(2);
      b_in <= abc(1);
      c_in <= abc(0);
      wait for 20 ns;

      -- expected = number of 1's among a, b, c
      expected := ("0" & abc(2)) + ("0" & abc(1)) + ("0" & abc(0));
      assert (t_out = expected(1)) and (s_out = expected(0))
        report "Error for abc = " & integer'image(i)
        severity error;
    end loop;

    report "full_adder testbench finished";
    wait;
  end process;

end test;
