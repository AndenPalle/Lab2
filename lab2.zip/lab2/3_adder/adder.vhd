-- adder.vhd
-- 02138 Digital Electronics 1, Lab 2, Section 3
-- 4-bit ripple-carry adder built from four full_adder instances (Figure 2).
-- s = x + y, where s(4) is the carry out.

library ieee;
use ieee.std_logic_1164.all;

entity adder is
  port ( x, y : in  std_logic_vector(3 downto 0);
         s    : out std_logic_vector(4 downto 0) );
end adder;

architecture structure of adder is

  component full_adder is
    port ( a, b, c : in  std_logic;
           s, t    : out std_logic );
  end component;

  signal m : std_logic_vector(3 downto 0);   -- internal carries

begin

  m(0) <= '0';   -- no carry into the least significant bit

  fa0: full_adder port map ( a => x(0), b => y(0), c => m(0), s => s(0), t => m(1) );
  fa1: full_adder port map ( a => x(1), b => y(1), c => m(1), s => s(1), t => m(2) );
  fa2: full_adder port map ( a => x(2), b => y(2), c => m(2), s => s(2), t => m(3) );
  fa3: full_adder port map ( a => x(3), b => y(3), c => m(3), s => s(3), t => s(4) );

end structure;
