-- adder_tb.vhd
-- Testbench for the 4-bit adder. Tries a handful of combinations
-- and checks each result.

library ieee;
use ieee.std_logic_1164.all;

entity adder_tb is
end adder_tb;

architecture test of adder_tb is

  component adder is
    port ( x, y : in  std_logic_vector(3 downto 0);
           s    : out std_logic_vector(4 downto 0) );
  end component;

  signal x_in, y_in : std_logic_vector(3 downto 0);
  signal s_out      : std_logic_vector(4 downto 0);

begin

  dut: adder port map ( x => x_in, y => y_in, s => s_out );

  stimulus: process
  begin
    -- Hex: 3 + 5 = 08   /  Bin: 0011 + 0101 = 01000
    x_in <= "0011"; y_in <= "0101"; wait for 20 ns;
    assert s_out = "01000" report "Error: 3 + 5" severity error;

    -- Hex: 5 + D = 12   /  Bin: 0101 + 1101 = 10010
    x_in <= "0101"; y_in <= "1101"; wait for 20 ns;
    assert s_out = "10010" report "Error: 5 + D" severity error;

    -- Hex: 0 + 0 = 00   /  Bin: 0000 + 0000 = 00000
    x_in <= "0000"; y_in <= "0000"; wait for 20 ns;
    assert s_out = "00000" report "Error: 0 + 0" severity error;

    -- Hex: 7 + 8 = 0F   /  Bin: 0111 + 1000 = 01111
    x_in <= "0111"; y_in <= "1000"; wait for 20 ns;
    assert s_out = "01111" report "Error: 7 + 8" severity error;

    -- Hex: F + 1 = 10   /  Bin: 1111 + 0001 = 10000  (carry through all stages)
    x_in <= "1111"; y_in <= "0001"; wait for 20 ns;
    assert s_out = "10000" report "Error: F + 1" severity error;

    -- Hex: A + 6 = 10   /  Bin: 1010 + 0110 = 10000
    x_in <= "1010"; y_in <= "0110"; wait for 20 ns;
    assert s_out = "10000" report "Error: A + 6" severity error;

    -- Hex: 9 + 4 = 0D   /  Bin: 1001 + 0100 = 01101
    x_in <= "1001"; y_in <= "0100"; wait for 20 ns;
    assert s_out = "01101" report "Error: 9 + 4" severity error;

    -- Hex: F + F = 1E   /  Bin: 1111 + 1111 = 11110
    x_in <= "1111"; y_in <= "1111"; wait for 20 ns;
    assert s_out = "11110" report "Error: F + F" severity error;

    -- Hex: D + 5 = 12   /  Bin: 1101 + 0101 = 10010
    -- (last line ends with a wait statement only)
    x_in <= "1101"; y_in <= "0101"; wait for 20 ns;
    assert s_out = "10010" report "Error: D + 5" severity error;

    report "adder testbench finished";
    wait;
  end process;

end test;
