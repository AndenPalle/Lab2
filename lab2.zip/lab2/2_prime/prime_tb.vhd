-- prime_tb.vhd
-- Testbench for prime: runs through all numbers 0..15 and checks isprime.

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity prime_tb is
end prime_tb;

architecture test of prime_tb is
  signal number_in   : std_logic_vector(3 downto 0);
  signal isprime_out : std_logic;
begin

  dut: entity work.prime
    port map ( number => number_in, isprime => isprime_out );

  stimulus: process
    variable expected : std_logic;
  begin
    for i in 0 to 15 loop
      number_in <= std_logic_vector(to_unsigned(i, 4));
      wait for 20 ns;

      case i is
        when 2 | 3 | 5 | 7 | 11 | 13 => expected := '1';
        when others                  => expected := '0';
      end case;

      assert isprime_out = expected
        report "Error for number = " & integer'image(i)
        severity error;
    end loop;

    report "prime testbench finished";
    wait;
  end process;

end test;
