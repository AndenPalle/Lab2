-- prime.vhd
-- 02138 Digital Electronics 1, Lab 2, Section 2.2
-- isprime = '1' when the 4-bit number is a prime (2, 3, 5, 7, 11, 13).
--
-- Karnaugh map (rows n3 n2, columns n1 n0), 1's at 2, 3, 5, 7, 11, 13:
--
--            n1n0:  00  01  11  10
--   n3n2 = 00        0   0   1   1     (3, 2)
--   n3n2 = 01        0   1   1   0     (5, 7)
--   n3n2 = 11        0   1   0   0     (13)
--   n3n2 = 10        0   0   1   0     (11)
--
-- Minimal sum of products:
--   isprime = n3'n2'n1  +  n2'n1n0  +  n2n1'n0  +  n3'n2n0

library ieee;
use ieee.std_logic_1164.all;

entity prime is
  port ( number  : in  std_logic_vector(3 downto 0);
         isprime : out std_logic );
end prime;

architecture behavior of prime is
begin
  isprime <= (not number(3) and not number(2) and number(1))     -- 2, 3
          or (not number(2) and number(1) and number(0))         -- 3, 11
          or (number(2) and not number(1) and number(0))         -- 5, 13
          or (not number(3) and number(2) and number(0));        -- 5, 7
end behavior;
